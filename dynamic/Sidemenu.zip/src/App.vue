<template>
  
  <Navbar/>
  <SideItems/>
</template>

<script>
import Navbar from './components/Navbar.vue'

import SideItems from './components/SideItems.vue' 

export default {
  name: 'App',
  components: { 
    Navbar,
    SideItems
  }
}
</script>


