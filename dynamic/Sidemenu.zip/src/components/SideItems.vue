<template>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
  <body>
    <ul class="sidebar">
    
    <li v-for="item in data" :key="item.id">
      
      <h1 v-on:click="item.show = !item.show" >
         {{item.name}}
        <span class="material-symbols-outlined">arrow_drop_down</span>
      </h1>
    <ul class="side-menu">

      <ul v-if="item.show">
        <li v-for="children in item.children" :key="children">
          <h1 v-on:click="children.show = !children.show">
            {{children.name}}
            
          </h1>
          <ul class="side-items">
          <ul v-if="children.show">
            <li v-for="children in children.next" :key="children">
              <h1>
                {{children.name}}
                
              </h1>
            
            </li>
            
          </ul>
          </ul>
        </li>
        </ul>
      </ul>
    </li>
  </ul>
  </body>
</template>
<script>
import jsonData from '/src/jsonData.json'
export default{
  data(){
    return{
     data:jsonData
    }
  }
}
</script>
<style scoped>
 
.body{
  background-color: aquamarine;
}
.sidebar{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  font-size: 16px;
  margin-top:30px;
  width: 100%;
  height: 100%;
  margin-left: 70px; 
  color:black;
  position:relative;
  
}
.side-menu{
  margin-left: 30px; 
  color: black;
 }
.side-menu h1{
  font-weight:bold;
  
  }
.side-menu h1:hover{
  background-color: transparent;
  color: #276cda;
}
.side-items{
  margin-left: 40px; 
  
  
}
</style>
